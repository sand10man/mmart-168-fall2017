/*
Instructions: Modify the function below so that adds an image to the #gallery element each time the user clicks the "Add Image" Button
*/

const addImage = () => {
  
}